﻿using UnityEngine;
using System.Collections;

public class Wall : MonoBehaviour {

    private AudioSource audio;//得到组件
    void Start()
    {
        audio = GetComponent<AudioSource>();//获取组件
    }

    void OnCollisionEnter2D()
    {
        audio.Play();//播放
    }

}
