﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GameManager : MonoBehaviour {


    private static GameManager _instance;//创建单例模式
    public static GameManager Instance
    {
        get
        {
            return _instance;//只能访问不能更改
        }
    }

    private BoxCollider2D rightWall;//取得右边墙
    private BoxCollider2D leftWall;//取得左边墙
    private BoxCollider2D downWall;//取得下边墙
    private BoxCollider2D upWall;//取得上边墙


    public Transform player1;//创建玩家1
    public Transform player2;//创建玩家2

    private int score1;//定义分数1
    private int score2;//定义分数2

    public Text score1Text;//定义组件
    public Text score2Text;//定义组件

    void Awake()
    {
        _instance = this;
    }
    
	// Use this for initialization
	void Start () {
        ResetWall();//调用ResetWall()方法
        ResetPlayer();//调用ResetPlayer（）方法
    }


    void ResetWall()//创建重置墙位置的方法
    {
        rightWall = transform.Find("rightWall").GetComponent<BoxCollider2D>();//取得右边墙的BoxCollider2D组件
        leftWall = transform.Find("leftWall").GetComponent<BoxCollider2D>();//取得右边墙的BoxCollider2D组件
        downWall = transform.Find("downWall").GetComponent<BoxCollider2D>();//取得右边墙的BoxCollider2D组件
        upWall = transform.Find("upWall").GetComponent<BoxCollider2D>();//取得右边墙的BoxCollider2D组件




        Vector3 tempPosition = Camera.main.ScreenToWorldPoint(new Vector2(Screen.width, Screen.height));//得到品目右上角点的坐标

        upWall.transform.position = new Vector3(0, tempPosition.y + 0.5f, 0);//得到上边墙位置
        upWall.size = new Vector2(tempPosition.x * 2, 1);//上边墙的尺寸大小

        downWall.transform.position = new Vector3(0, -tempPosition.y - 0.5f, 0);//得到下边墙位置
        downWall.size = new Vector2(tempPosition.x * 2, 1);//下边墙的尺寸大小

        rightWall.transform.position = new Vector3(tempPosition.x + 0.5f, 0, 0);//得到右边墙位置
        rightWall.size = new Vector2(1, tempPosition.y * 2);//右边墙的尺寸大小

        leftWall.transform.position = new Vector3(-tempPosition.x - 0.5f, 0, 0);//得到左边墙位置
        leftWall.size = new Vector2(1, tempPosition.y * 2);//左边墙的尺寸大小

    }

    void ResetPlayer()//创建重置
    {
        Vector3 player1Position = Camera.main.ScreenToWorldPoint(new Vector3(100, Screen.height / 2, 0));//屏幕坐标转换成世界坐标
        player1Position.z = 0;//对z轴设置为0
        player1.position = player1Position;//赋值
        Vector3 player2Position = Camera.main.ScreenToWorldPoint(new Vector3(Screen.width - 100, Screen.height / 2,0));//屏幕坐标转换成世界坐标
        player2Position.z = 0;//把z轴归为0
        player2.position = player2Position;//赋值
    }

    public void ChangeScore( string wallName )
    {
        if (wallName == "leftWall")//如果碰到的是左边的墙
        {
            score2++;//分数2加一分
        }
        else if (wallName == "rightWall")//如果碰到的是右边的墙
        {
            score1++;//分数1加一分
        }

        score1Text.text = score1.ToString();//更新UI
        score2Text.text = score2.ToString();//更新UI
    }

    public void Reset()//重置方法
    {
        score1 = 0;//分数一归零
        score2 = 0;//分数二归零
        score1Text.text = score1.ToString();//更新UI的显示
        score2Text.text = score2.ToString();//更新UI的显示
        GameObject.Find("Ball").SendMessage("Reset");//当按下按钮时找到小球调用重置方法
    }
}
