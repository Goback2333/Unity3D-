﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {


    public KeyCode upKey;//控制上移动
    public KeyCode downKey;//控制下移动
    public float speed = 10;//设置移动的速度

    private Rigidbody2D rigidbody2D;//得到刚体
    private AudioSource audio;//得到声音组件

    void Start()
    {
        audio = GetComponent<AudioSource>();//获取组件
        rigidbody2D = GetComponent<Rigidbody2D>();//得到刚体
    }
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKey(upKey))//如果按下了向上的键
        {
            rigidbody2D.velocity = new Vector2(0, speed);//给在Y轴上向上的速度
        }
        else if(Input.GetKey(downKey))//如果按下了向下的键
        {
            rigidbody2D.velocity = new Vector2(0, -speed);//给在Y轴上向下的速度
        }
        else
        {
            rigidbody2D.velocity = new Vector2(0, 0);//当没有按下时，则没有速度
        }


	}

    void OnCollisionEnter2D()
    {
        audio.pitch = Random.Range(0.8f, 1.2f);//声音播放声音的随机速度
        audio.Play();//播放声音
    }
}
