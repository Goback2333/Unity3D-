﻿using UnityEngine;
using System.Collections;

public class Ball : MonoBehaviour {

    private Rigidbody2D rigidbody2D;//获取刚体组件

    // Use this for initialization
    void Start () {
        rigidbody2D = GetComponent<Rigidbody2D>();//得到刚体组件
        GoBall();//调用方法
    }


    void Update()
    {
        Vector2 velocity = rigidbody2D.velocity;//速度
        if (velocity.x < 9 && velocity.x > -9 &&velocity.x!=0)//如果X轴速度小于9或大于-9而且x速度不等于0时
        {
            if (velocity.x > 0)//如果x轴速度为正
            {
                velocity.x = 10;//让X速度恢复到10
            }
            else//如果X轴速度为负
            {
                velocity.x = -10;//让X速度恢复到负10
            }
            rigidbody2D.velocity = velocity;//让速度回去
        }
    }

    void OnCollisionEnter2D(Collision2D col)//碰撞检测的的方法
    {
        if (col.collider.tag == "Player")//如果碰撞到的是player
        {
            Vector2 velocity = rigidbody2D.velocity;//速度
            velocity.y = velocity.y/2f + col.rigidbody.velocity.y/2;//原来速度减半+当前角色速度减半
            rigidbody2D.velocity = velocity;//设置速度

        }
        if (col.gameObject.name == "rightWall" || col.gameObject.name == "leftWall")//如果小球碰撞到的是左边墙或是右边的墙
        {
            GameManager.Instance.ChangeScore( col.gameObject.name);//调用方法创建
        }
    }


    public void Reset()
    {
        transform.position = Vector3.zero;//使小球位置归零
        GoBall();//调用方法
    }

    void GoBall()
    {
        int number = Random.Range(0, 2);//设置随机数
        if (number == 1)
        {
            rigidbody2D.AddForce(new Vector2(100, 0));//右边给100N的力
        }
        else
        {
            rigidbody2D.AddForce(new Vector2(-100, 0));//左边给100N的力
        }
    }

}
